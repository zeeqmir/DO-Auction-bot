﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace DO_Login.Models
{
    public class UserModel
    {
        public String SID { get; set; }
        public String credits { get; set; }
        public String server { get; set; }
        public String name { get; set; }
    }
}
